# AGENTS.md

## Project overview

"Yijing Awareness" (Yi Jing Presence) — a React SPA implementing an I Ching-based mindfulness
practice: cast a hexagram, read its wisdom, pick a changing line, see the transformed hexagram,
and work through an AI-guided presence session (body → emotions → thoughts). This codebase was
rebuilt from the production bundle of https://yijingaware.netlify.app; all domain data was
extracted verbatim from that bundle.

## Architecture

- **Vite + React 18 + TypeScript SPA**, single page, no client router. Entry:
  `index.html` → `src/main.tsx` → `src/App.tsx`.
- `src/data/hexagrams.ts` — the 64 hexagrams (name, subtitle, description, judgment, six line
  texts) as a `Record<number, HexagramData>`. Generated file; treat as data, not hand-edited text.
- `src/data/videos.ts` — one YouTube link per hexagram.
- `src/lib/casting.ts` — the I Ching arithmetic:
  - lines are coin sums: 6 = old yin (changing), 7 = yang, 8 = yin, 9 = old yang (changing);
  - `linesToHexagramNumber` maps the 6-bit binary (yang = "1", lines bottom-up) to hexagram 1–64
    via `BINARY_TO_HEXAGRAM` (King Wen ordering, extracted from the original bundle — do not
    "fix" entries);
  - `transformedHexagramNumber` normalizes ALL changing lines (6→7, 9→8) then re-maps. The
    selected dominant line does NOT affect the transformed number — it only steers the AI
    conversation focus. This matches the original app's behavior (verified against all 4096
    possible casts).
- `src/lib/iching.ts` — shared types (LineValue, ChatMessage, Focus).
- `src/lib/hooks.ts` — dark mode (default dark), online status, service-worker registration.
- Components in `src/components/`:
  - `HexagramLines` — animated line stack (bottom-up, reversed array, changing-line dot markers);
  - `HexagramCard` — name/subtitle/description/judgment card;
  - `ChangingLines` — selector for dominant changing line, or "no changing lines" state;
  - `PresenceSession` — the AI chat; posts `{ prompt }` to `/api/presence`; 20s auto-progression
    through focus stages; 10-minute auto-completion message; offline/error fallbacks;
  - `InstallButton` — PWA install (uses `window.__installPrompt` captured in index.html);
  - `QuestionInput`, `ui/*` — small primitives (Button, Input, Textarea).

## Backend

- `netlify/functions/presence.ts` — Netlify Function v2 (`export default async (req, context)`)
  at path `/api/presence`. Uses the zero-config Anthropic SDK (Netlify AI Gateway injects
  credentials at runtime; legacy v1 `exports.handler` style would NOT get credentials). Model:
  `claude-haiku-4-5`, max_tokens 300. Never returns errors to the client — falls back to a static
  guidance line so the practice always continues.

## Conventions

- TypeScript strict mode; path alias `@/*` → `src/*`.
- Tailwind utility classes inline; dark/light handled via a `darkMode` boolean prop with ternary
  class strings (gray-800/gray-50 pattern) — matches the original design.
- Framer Motion entrance animations (`initial/animate` with y-offset) throughout.
- No comments in code unless necessary.

## Non-obvious decisions

- Data files are generated from the original production bundle (see README). The binary→hexagram
  map and all copy are intentional ports; any "missing" hexagram numbers in the map would be a
  data bug, not a style choice.
- The coin toss uses `Math.floor(Math.random() * 2) + 2` per coin (2 or 3), summing three coins
  per line — uniform distribution over 6/7/8/9, same as the original (a simplification of true
  three-coin probabilities).
- `public/sw.js` is a plain hand-written service worker (network-first navigations, cache-first
  assets), registered in `src/lib/hooks.ts`.
- SPA fallback lives in `netlify.toml` (redirect `/*` → `/index.html`, status 200).

## Build/deploy

- `npm run build` = `tsc && vite build` → `dist/`; functions from `netlify/functions`.
- Do not run builds in agent sessions; the platform validates builds automatically. `npx tsc --noEmit`
  is safe for type checking.