# Yijing Awareness (Yi Jing Presence)

A mindfulness and self-reflection web app built around the I Ching (Book of Changes). Visitors
describe their current state or a question, cast a hexagram with simulated three-coin tosses, and
are guided through a presence-based reflection session — body sensations, emotions, and thoughts —
led by an AI guide grounded in the wisdom of their hexagram and changing lines.

This is a rebuild of the original site hosted at https://yijingaware.netlify.app ("Synchronicity /
Yijing Awareness"), restored as an installable PWA on this project.

## Features

- **Hexagram casting** — six three-coin tosses (values 6–9 per line) with a 2-second breathing
  pause, rendered as animated stacked lines with changing-line markers.
- **Full 64-hexagram dataset** — name, subtitle, description, judgment, and all six line texts for
  every hexagram, ported verbatim from the original app.
- **Changing lines** — select a dominant changing line to reveal the transformed hexagram and
  focus the reflection on that line's teaching.
- **AI presence session** — a guided chat (body → emotions → thoughts progression) powered by a
  Netlify Function calling Claude Haiku through Netlify AI Gateway (no API keys required). Falls
  back to simplified static guidance when offline or on error.
- **Guided videos** — a "Watch Video" link for each of the 64 hexagrams.
- **PWA** — installable on iOS/Android/desktop with manifest, service worker (offline shell), and
  per-platform install instructions.
- **Dark / light mode toggle.**

## Tech stack

- React 18 + TypeScript + Vite
- Tailwind CSS
- Framer Motion animations
- lucide-react icons
- Netlify Functions (TypeScript, v2 style) + Netlify AI Gateway (@anthropic-ai/sdk)

## Run locally

```bash
npm install
npm run dev          # Vite dev server at http://localhost:5173
```

To run with the Netlify Function locally (AI guide):

```bash
netlify dev --port 8889
```

The presence function lives at `netlify/functions/presence.ts` and is served at `/api/presence`.
It requires Netlify AI Gateway environment variables, which Netlify injects automatically in
deployed and `netlify dev` environments.

## Build

```bash
npm run build        # typechecks and outputs to dist/
```

Deployment is configured via `netlify.toml`: build from `dist/`, functions from
`netlify/functions/`, SPA fallback redirect for client routing, and static assets served from
`public/` (manifest, service worker, icons).