import { motion } from "framer-motion";
import { HEXAGRAMS } from "@/data/hexagrams";

interface Props {
  hexagramNumber: number;
  isTransformed?: boolean;
  darkMode: boolean;
}

export default function HexagramCard({ hexagramNumber, isTransformed = false, darkMode }: Props) {
  const hex = HEXAGRAMS[hexagramNumber];
  if (!hex) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl p-8 md:p-12 ${darkMode ? "bg-gray-800" : "bg-gray-50"}`}
    >
      <div className="text-center mb-8">
        <h2 className={`text-2xl mb-2 ${darkMode ? "text-gray-200" : "text-gray-900"}`}>
          {hex.name}
        </h2>
        <p className={darkMode ? "text-gray-400" : "text-gray-600"}>{hex.subtitle}</p>
      </div>
      <div className="mb-8">
        <p className={darkMode ? "text-gray-300" : "text-gray-700"}>{hex.description}</p>
      </div>
      {hex.judgment && (
        <div className={`mb-8 pt-6 border-t ${darkMode ? "border-gray-700" : "border-gray-200"}`}>
          <p className={`italic ${darkMode ? "text-gray-400" : "text-gray-600"}`}>
            {hex.judgment}
          </p>
        </div>
      )}
    </motion.div>
  );
}