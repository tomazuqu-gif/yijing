export interface HexagramData {
  name: string;
  subtitle: string;
  description: string;
  judgment: string;
  lines: Record<string, string>;
}

export const HEXAGRAMS: Record<number, HexagramData> = {
  1: {
    name: "The Origination",
    subtitle: "Heaven",
    description: "The Origination embodies a primal energy of creation, a principle behind every endeavor and all things coming into being. We align with this principle when we have an inner vision or inspiration of what we need or who we truly are, allowing this inner power to shape reality. Just as a great dragon soars freely across the heavens, this force empowers all things to rise, expand, and express their true nature.",
    judgment: "Heaven. Primordial. Smooth progress and advantage. Integrity.",
    lines: {
    1: "Hidden dragon, no need to act.",
    2: "The dragon appears on earth. It brings good fortune to see this great being.",
    3: "The superior man is diligent all day long; in the evening, he remains cautious as if in danger. Though there is peril, there will be no misfortune.",
    4: "Perhaps it will soar from the abyss, this is without fault.",
    5: "The flying dragon is in the sky; it is beneficial to see the great being.",
    6: "The high-soaring dragon doubts himself"
    },
  },
  2: {
    name: "The Receptive",
    subtitle: "Earth",
    description: "The Receptive embodies a primal energy of nourishment. By allowing everything to unfold in its own time, we align with this principle when we surrender with ease to whatever arises on our path, trusting that what we seek will grow when the time is right. Just as fertile soil nourishes both the tallest trees and the smallest flowers, this principle sustains whatever comes into being.",
    judgment: "The Receptive (or \"the field\"). Effortless progress. Favourable to move like a mare. The great person is driven by his purpose; First feeling lost, then finding clarity (If you go forth, you will lose your way; if you follow, you will find guidance) Advantage in sustaining oneself in the southwest. In the northeast sustenance leaves. With calm and upright attitude one receives good fortune",
    lines: {
    1: "Treading on frost, solid ice will soon arrive.",
    2: "Straight, square and great (also honest, aligned with the principle and expansive). Without repeated practice, nothing is without benefit.",
    3: "Hiding brilliance leads to correctness; it allows one to assist the king in his duties. By avoiding recognition, one reaches true completion.",
    4: "Close the bag. No blame, no praise",
    5: "Yellow robe. Supreme good fortune",
    6: "Dragons battle in the wild. Their blood is black and yellow"
    },
  },
  3: {
    name: "Hardship at the Transition",
    subtitle: "Initial Difficulty",
    description: "Hardship at the beginning reflects the inevitable chaos and struggle that arise when releasing resistance before full trust in life can take root. Effort and resistance create friction before ease unfolds. By trusting the process, letting go of control, and seeking wise guidance, life flows naturally bringing prosperity in all areas.",
    judgment: "Hardship at the Transition. Great success. Favourable to be steadfast. Do not act rashly. It is beneficial to establish leaders.",
    lines: {
    1: "Remain in place, grounded. Staying with what is right is beneficial. It is beneficial to appoint a leader",
    2: "Hardship, wavering again and again. Riding a horse, yet hesitating. Not an enemy, but seeking union. Like a woman who does not marry—one does not commit, but after ten years, a commitment is made.",
    3: "Chasing a deer without a forest guide. One enters the deep forest. The great person understands the early indications.",
    4: "Riding a horse in a united, orderly formation. Seeking union and harmony. To proceed is auspicious. Nothing is unfavourable.",
    5: "Difficulty in prosperity. Small effort brings good fortune. Large effort brings harm.",
    6: "Riding a horse but stopping and turning back. Weeping tears of blood."
    },
  },
  4: {
    name: "Inexperience",
    subtitle: "Youthful Folly",
    description: "Youthful Folly represents the energy of a beginner seeking knowledge. It is a time of curiosity but also one where guidance is essential. Youthful Folly isn't a fault but a phase emphasizing the need for discipline and learning. It invites patience and steady development.",
    judgment: "The Beginner. Smooth progress. \"'I' is not what the Beginner seeks, but an ignorant searches for 'I'. Intention brings its corresponding result. The first bite results in self-trust. But wavering enquiry is no longer pure and cannot not guide. This is a corrupted beginner. Because beginner nurtures authenticity—this is the work of the Sage",
    lines: {
    1: "Ignorance awakened brings movement. It is favourable to apply firm correction. If the shackles are removed, to press further brings regret.",
    2: "To embrace the beginner brings good fortune. Taking a wife brings good fortune. The son can manage the household",
    3: "Do not take the woman. She sees a man of gold, she loses herself, no benefit anywhere.",
    4: "Inexperience is blocked. There will be reasons for regret.",
    5: "Inexperience of young child. Good fortune.",
    6: "Attack of inexperienced, it does no good to commit a violation. The idea is to prevent a violation."
    },
  },
  5: {
    name: "Waiting",
    subtitle: "Nourishment",
    description: "Waiting advises patience and trust in the right timing. It encourages you to pause and remain steady. Success will come if you endure the initial challenges with calm resolve. Engaging too early may lead to entanglements.",
    judgment: "Waiting: trust alignment—radiant and developing with ease. Remaining aligned is good fortune. Favorable to cross the great river",
    lines: {
    1: "Waiting at the suburbs. It is beneficial to remain in place. The is no error in this.",
    2: "The second line shows one waiting by the sands; a few words arise—ultimately good fortune.",
    3: "The third line shows one waiting in the mud; bandits arrive.",
    4: "Waiting in blood; emerging from the pit.",
    5: "The fifth line shows one waiting with wine and food; correct perseverance brings good fortune.",
    6: "Entering the cave; three unexpected guests arrive—honor them, and it ends well."
    },
  },
  6: {
    name: "Conflict",
    subtitle: "Stress",
    description: "Conflict arises when two forces collide—one firm and upward moving, the other perilous and yielding. This hexagram advises caution, alignment with truth, and navigating disputes effectively. It describes a situation of potential discord that can lead to ruin if mishandled, but can also yield stability and growth when approached with integrity.",
    judgment: "Conflict. Truth is upheld. Obstacles create caution. Remaining centered brings good fortune. Persistence ends in misfortune. It is beneficial to seek the guidance of a great person. It is not favorable to cross great rivers.",
    lines: {
    1: "Do not prolong the affair; minor words or complaints may arise, but in the end, good fortune comes.",
    2: "Unable to win the conflict. Return and withdraw. No harm will come to the three hundred families of your town.",
    3: "To live on the virtue of one's ancestors (lit. to eat the old virtue). Persevering in this brings danger, but in the end, good fortune. If you should perhaps undertake the king's business, do not seek what is complete.",
    4: "Unable to win the conflict. Return and accept your fate. Change your approach, remain calm and upright—then, good fortune.",
    5: "Conflict. There will profound good result.",
    6: "Some may award him a leather belt (a symbol of honor), but by the end of the morning it is taken away three times."
    },
  },
  7: {
    name: "The Army",
    subtitle: "Discipline",
    description: "The Army represents the disciplined unification of external efforts or internal aspects of the self. This may refer to guiding others or organizing your own inner resources. It emphasizes leadership, integrity, and purposeful action.",
    judgment: "The military force. Remaining stable of an elder leader. Good fortune without error",
    lines: {
    1: "At the beginning, the force moves in accordance to orders received. If discipline is lacking, misfortune follows",
    2: "Remaining at the center of the military force — good fortune, without error. The king thrice bestows commands",
    3: "The army wagon carries corpses. Misfortune",
    4: "The army positions itself on the flank, not launching a frontal attack. No blame",
    5: "There are birds in the field. It is beneficial to speak honestly. No blame. The elder son leads the army; the younger carries corpses. Persevering in the wrong way brings misfortune",
    6: "The great leader issues commands, founding states and securing families. Do not rely on the small-minded"
    },
  },
  8: {
    name: "Holding Together",
    subtitle: "Union",
    description: "Holding Together speaks to the quiet strength found in unity. There's good fortune in willingly aligning with others. It's about trust and openness and a shared vision—not about losing one's identity. Unity is a mutual choice to gather around common values.",
    judgment: "Holding Together (Union). This is aligned and auspicious. Consult your motivation (the source) about origination, endurance, and stability. Without fault. Restlessness comes. Late comers meet misfortune",
    lines: {
    1: "Trusting union with others brings no fault. Full trust fills the jar to the brim; in the end, it brings further good fortune",
    2: "Union from within, trusting your direction leads to good fortune",
    3: "Hold together with the wrong people.",
    4: "Hold together outwardly. Perseverance brings good fortune.",
    5: "A sign of holding together. The king uses the three drives for his hunt. He lets the animals escape. The citizens need no warning. Good fortune.",
    6: "Seeking union but finding no leader brings misfortune."
    },
  },
  9: {
    name: "Taming Power of the Small",
    subtitle: "Small Accumulating",
    description: "Compounding of Subtle advises trusting yourself and exerting subtle, almost unfelt influence. This action will be incremental and over time have a profound effect. Like an archer drawing back their bow string—the bow is full of potential energy, but if released too soon the arrow lacks direction and force.",
    judgment: "Compounding of Subtle (or Subtle Taming). Success. Dense clouds gather but there is no rain. They come from the western regions.",
    lines: {
    1: "Returning to one’s path—what fault is there? Good fortune.",
    2: "He is pulled back to the right path. Good fortune.",
    3: "The wheel spokes of the cart are loose. Husband and wife turn against each other.",
    4: "There is heartfelt trust. Peril goes away and fear dissolves. There will be no fault.",
    5: "Heartfelt trust that draws wealth from its neighbors.",
    6: "It has already rained, and water now settles. Trust is what supports. A woman’s correctness is dangerous. The moon is nearly full. To take action will leads to misfortune for the great person."
    },
  },
  10: {
    name: "Treading",
    subtitle: "Cautious Advance",
    description: "Treading represents the delicate situation where there is a danger which needs to be recognized and navigated carefully. The challenge is compared to a risk of being bitten by a tiger while stepping on its tail. This could be making a critical life decision or speaking out against injustice. Progress here is possible but we need to behave with care and balance.",
    judgment: "Treading. Treading on the tiger’s tail. It does not bite the man. Success.",
    lines: {
    1: "Step simply and humbly, and no harm will come",
    2: "Walking the path in a smooth way. The person hiding in seclusion having confidence in his destiny finds good fortune.",
    3: "Though short-sighted, one can still see. Though lame, one can still tread. Tread on the tiger’s tail, and it will bite a person, causing harm. A warrior serves the great lord.",
    4: "Treading very cautiously on sensitive points of raw authority. Good fortune in the end",
    5: "Step boldly, but with heart aligned. In peril, the upright path can be stabile.",
    6: "Looking at own conduct examining intentions. Your path turns inward and is true — you walk in blessing"
    },
  },
  11: {
    name: "Peace",
    subtitle: "Harmony",
    description: "Peace is harmony between forces, an alignment of all elements. For example, when the mind and heart work as one, actions become effortless. The Horizon is where sky and Earth meet—the heavens vast and untouchable, the Earth solid and grounded—yet without one the other loses meaning.",
    judgment: "Peace. The small departs, the great arrives. Good fortune and success",
    lines: {
    1: "Grass is pulled up together with its roots. This is because of their unity. Going forward is auspicious",
    2: "Embrace desolation (lit. \"embrace wilderness or unrefined\"). Wade through rivers. Do not forsake the distant when friends are gone. Reach completion through highest humility",
    3: "No evenness without slope, no going without returning, difficulty and stability are without error. Do not worry where there is trust. Life sustenance is blessing.",
    4: "Free like a bird, without riches - employing his neighbour, not vigilant but trusting unfolding",
    5: "The Emperor Yi marries off his daughter. This leads to great fortune and supreme favor",
    6: "The city turns into a moat. Do not use the army. Orders arise from within the city itself. Persistence brings distress"
    },
  },
  12: {
    name: "Standstill",
    subtitle: "Stagnation",
    description: "Stagnation represents a period of blockage and disconnection. It reflects times when harmony fades and progress halts. Petty influences rise over noble ones. Despite this, there is wisdom in stillness and patience.",
    judgment: "Stagnation is not of the true human. It does not bring benefit for the noble one to strive. The great departs; the small approaches.",
    lines: {
    1: "Pulling out grass along with its roots as they come together. Honest holding to your direction brings good fortune and success.",
    2: "Enclose trap and bear the burden. The petty person finds good fortune, the great one is blocked. Yet smooth progress comes",
    3: "Containing shame",
    4: "Align with the higher principle; this is without error. Those who are aligned share blessings",
    5: "The end of stagnation. For the great person, good fortune. It is really gone! It is now natural like a mulberry tree.",
    6: "Stagnation collapses. First there is stagnation, then comes joy."
    },
  },
  13: {
    name: "Fellowship",
    subtitle: "Unity of Forces",
    description: "Fellowship with others brings harmony and success. By venturing into open spaces, cooperation thrives. Crossing great rivers is favorable. A noble person finds strength in integrity. When your thoughts, emotions, and actions work together you become a unified, purposeful individual.",
    judgment: "Fellowship with men in the wilderness. Success. It is favorable to cross the great river. It benefits the great person to remain steadfast.",
    lines: {
    1: "Fellowship at the gate. No blame.\" - alternative translation - \"“At the threshold of alignment. There is no blame.",
    2: "Focusing on intimate or close relations – not yet broad fellowship; still limited.",
    3: "Weapons are hidden in the wild. One climbs the high hill. For three years, nothing arises.",
    4: "He climbs up on his defences; strongly refuses to fight the attack. Good fortune.",
    5: "Fellowship with men. First there is weeping and wailing, then laughter comes. The great leader succeeds in meeting others.",
    6: "Union with people in the open fields. No regret."
    },
  },
  14: {
    name: "Great Possession",
    subtitle: "Wealth",
    description: "Possession in Great Measure is about abundance and success—not just material wealth but clarity, purpose, and virtue. It's a time to use what you have wisely and align your actions with higher principles. Success comes from combining strength with wisdom.",
    judgment: "Great Possession. Supreme success",
    lines: {
    1: "Meeting it cannot bring harm, because there is no error; even if the situation feels hard, there can be nothing wrong",
    2: "The great cart carries, there is destination, this is without error.",
    3: "The noble person offers his life to his life’s purpose (lit. to the highest authority). The small-minded cannot do this",
    4: "Avoid arrogance, no blame.",
    5: "One is truthful in connecting and dignified; good fortune.",
    6: "Help comes from Heaven, the Creative power that initiates all things. Everything is auspicious; nothing is unfavorable."
    },
  },
  15: {
    name: "Modesty",
    subtitle: "Humbleness",
    description: "Modesty represents a way of being that doesn't seek attention yet remains powerful. It stands for a quiet presence. Modesty symbolizes the subtle force that aligns with life's natural rhythms. The modest person accomplishes without demanding recognition, ensuring their influence endures.",
    judgment: "Modesty creates success. The noble one will have an enduring outcome.",
    lines: {
    1: "Being moderate about moderation can be used to cross the great river. Great progress.",
    2: "Moderation speaks out. Integrity brings good fortune.",
    3: "In effort, not asserting oneself; the true person has an end. Auspicious",
    4: "There is nothing that is not beneficial, when demonstrate true modesty",
    5: "Not enriching oneself and remaining aligned with neighbors; this allows undertaking a corrective campaign; nothing is unfavourable",
    6: "Declare your modesty. Advantageous to lead an army to subdue towns and nations."
    },
  },
  16: {
    name: "Enthusiasm",
    subtitle: "Providing For",
    description: "Enthusiasm represents a time of preparation and energetic alignment with favorable circumstances. It is about gathering strength and motivating collective action. The mood is one of joyful anticipation and readiness to act. This could be organizing a community effort, planning a major project, or rallying others towards a shared vision.",
    judgment: "Enthusiasm. It is beneficial to establish leaders and mobilize forces.",
    lines: {
    1: "Screaming enthusiasm: misfortune.",
    2: "Firm like a rock. It does not last the day . Keeping to the own direction brings good fortune.",
    3: "Enthusiasm that looks upward – regret. Hesitation brings relief.",
    4: "Through true enthusiasm great gains are obtained. Do not doubt. Friends gather together like hair bound by a pin.",
    5: "Holding too tightly and grows sick, yet continues on.",
    6: "Mysterious enthusiasm, completion brings transformation. This is without fault."
    },
  },
  17: {
    name: "Following",
    subtitle: "Adapting",
    description: "Following is allowing the natural order or unfolding. When one stops trying to lead and instead follows the natural course, one discovers the way. The right moment, the natural unfolding of events brings all phases of development to completion.",
    judgment: "Following - creative (or origination), developing with ease (unfolding), receiving and remaining in alignment. This is without error",
    lines: {
    1: "The authorities have changed. Staying correct brings good fortune. Going out and engaging with others brings success.",
    2: "Attachment to the boy causes the loss of the nature man",
    3: "Connection with the mature man — the boy is lost. By continuing, what is desired is achieved",
    4: "Following along brings gain. Remaining grounded and stable leads to misfortune. Have trust in your own Way and clarity will follow. What fault could be there?",
    5: "Trusting and aligning the highest goodness brings good fortune",
    6: "One is bound to follow, then releasing the bound By stopping at completion, there is culmination which may last without descending"
    },
  },
  18: {
    name: "Work on What Has Been Spoiled",
    subtitle: "Repair",
    description: "This hexagram addresses decay, corruption, or neglect that has accumulated over time. It calls for deliberate effort to repair and renew. Success comes from confronting problems directly and taking responsibility for restoration.",
    judgment: "Decay. Great success. Favourable to cross the great river. Three days before the start; three days after the start.",
    lines: {
    1: "Setting right what has been spoiled by the father - the late father is without blame. Ascending to good fortune.",
    2: "Setting right what has been spoiled by the mother. It is not permissible to be rigidly correct.",
    3: "Setting right what has been spoiled by the father. There will be a little remorse, but not a big error.",
    4: "Tolerating what has been spoiled by the father. If one proceeds like this, one will encounter humiliation.",
    5: "Setting right what has been spoiled by the father. It attracts praise, earns honor, and builds a good reputation.",
    6: "He does not serve external authority (lit. king and prince). He values higher matters."
    },
  },
  19: {
    name: "Approach",
    subtitle: "Nearing",
    description: "Approach represents advancing forward with care and awareness. It is a time of increasing influence and growth. However, this favorable period is temporary, requiring mindful action while it lasts.",
    judgment: "Approach. Great progress. Favourable to remain in place. By the eighth month there will be misfortune.",
    lines: {
    1: "Heart-felt approach. Dwelling in abundance brings good fortune.",
    2: "Heart-felt approach. Good fortune, nothing not beneficial",
    3: "Approaching joyfully. Yet there may still remain worry that this will not last. But there will be no fault",
    4: "Approach that has reached the complete stage, it's without error",
    5: "Wisdom approaching that of the great ruler's. Good fortune",
    6: "Stable approach. Good fortune without error"
    },
  },
  20: {
    name: "Contemplation",
    subtitle: "Viewing",
    description: "Contemplation represents observation, reflection, and seeing the larger patterns. It is a time for looking deeply rather than acting hastily. Understanding comes through patient, mindful awareness.",
    judgment: "Contemplation. Completing purification without sacrifice. Having earnest sincerity and a respectful demeanor.",
    lines: {
    1: "Crude, immature observation. For an inferior man, no blame. For a superior man, humiliation",
    2: "Peeping through a crack — partial, limited insight.",
    3: "Observation, progress and retreat.",
    4: "Observing the light of the kingdom — the sage’s broad perspective.",
    5: "Observing one’s own conduct — self-reflection of a leader.",
    6: "Observing one's life, the noble one has no fault."
    },
  },
  21: {
    name: "Biting Through",
    subtitle: "Eradicating",
    description: "Biting Through represents decisive action to remove obstacles. When something blocks progress, firm intervention is needed. This hexagram often relates to justice, clarity, and cutting through resistance.",
    judgment: "Biting Through. Success. It is beneficial to administer justice.",
    lines: {
    1: "His feet are in the stocks. He loses his nose.",
    2: "Bites through tender meat. He loses his nose.",
    3: "Bites on dried meat. Encounters poison. Small humiliation.",
    4: "Biting into dried, sinewy meat (gristle). Obtains a metal arrow. Favorable to remain constant through difficulty. Good fortune.",
    5: "Bites on dried meat. Gets yellow gold. Perseverance brings danger.",
    6: "Bearing the cangue that covers the ears. Disaster."
    },
  },
  22: {
    name: "Grace",
    subtitle: "Adorning",
    description: "Grace represents beauty, refinement, and the harmonious expression of substance through form. It is about adding elegance to what is solid and meaningful. True grace comes from the balance of inner worth and outer presentation.",
    judgment: "Grace. Success. It is slightly beneficial to have somewhere to go.",
    lines: {
    1: "Grace adorns the toes; abandoning the carriage, one goes on foot",
    2: "Grace adorns the beard",
    3: "Grace that is dew-covered — this natural, enduring alignment brings good fortune",
    4: "Grace like whiteness, like a white horse with plume; not a bandit, but one coming to wed",
    5: "Graceful adornment in the hill garden, with but a scant bundle of silk; regret, yet ultimately auspicious",
    6: "White grace. There is no error in this."
    },
  },
  23: {
    name: "Splitting Apart",
    subtitle: "Falling Away",
    description: "Splitting Apart represents a time of decline and decay. It advises caution, restraint and acceptance of inevitable endings. This marks a period when structures weaken; only careful navigation prevents further harm.",
    judgment: "Splitting Apart. It is not beneficial to proceed anywhere.",
    lines: {
    1: "Splitting the bed at the foot. Losing your soul (undermining the upright fulness) brings misfortune",
    2: "Splitting the bed at the frame. Losing your soul (undermining the upright fulness) brings misfortune",
    3: "Removing what covers is without fault",
    4: "Splitting the bed at the skin brings misfortune",
    5: "Stringing fish in order. Thanks to the favor of court attendants, nothing is unfavorable",
    6: "The large fruit remains uneaten. The noble person receives support to move forward — if small-minded, one loses shelter"
    },
  },
  24: {
    name: "Return",
    subtitle: "Turning Back",
    description: "Return symbolizes a fresh beginning, like the first glimmer of dawn after a long night. It is a time to embrace renewal, reconnect with your core path, and align with natural rhythms. Thunder within the Earth symbolizes gentle stirring.",
    judgment: "Return: Effortless success Going out and coming is without forcing; friends arrive without any error Turning back to return to own way, a return after complete cycle (lit. seven days); it is beneficial to go somewhere",
    lines: {
    1: "Returning from not far. No need for regret. Great good fortune",
    2: "Quiet return. Good fortune",
    3: "Repeatedly returning. There is danger, but no error",
    4: "Coming to the centre, returning to oneself",
    5: "Quiet, grounded (lit. thick) return. No regret",
    6: "Deluded return. Misfortune. Natural disasters and military defeat. Persistent error leads to loss."
    },
  },
  25: {
    name: "Undeluded",
    subtitle: "Not Deluded About the Truth",
    description: "To live undeluded is to let our choices and inner life align with beliefs that genuinely reflect reality. When our beliefs are clear and truthful, they support us like a well-lit path. Success comes from following your authentic path without distortion.",
    judgment: "Undeluded (or not deluded about the truth). Supreme smooth progress. It is beneficial to trust your Way. If you lose this trust, error appears. No other direction is favorable.",
    lines: {
    1: "Undeluded is what brings good fortune.",
    2: "Without plowing or sowing, one still reaps; without preparing the field, there is benefit in moving forward.",
    3: "Undeluded about loss. Someone ties an ox. A traveling tradesman gains, a townsman losses.",
    4: "It is permissible to keep the direction, there is no fault.",
    5: "Undeluded deals with a problem. Do not correct it — there will be joy.",
    6: "Undeluded. To move forward brings error. Aimlessness gives a favourable outcome."
    },
  },
  26: {
    name: "Great Accumulation",
    subtitle: "Taming Force",
    description: "Taming the Great represents possessing great power and managing it wisely. True power is not about dominance but about mastering ourselves. Heaven's energy rests within the mountain—wisdom contained within strength.",
    judgment: "Taming Force (or Great Accumulation). Beneficial to persevere. Avoid eating at home; it is auspicious. Advantageous to cross great rivers.",
    lines: {
    1: "There is harsh strictness, favorable to temper oneself.",
    2: "The carriage’s yoke/strap is set so the wheel fits.",
    3: "Noble action in pursuit. Challenging integrity brings benefit. It is said: restrain the carriage and guard well. Favorable to remain clear about your direction.",
    4: "A young ox with a yoke, brings great good fortune.",
    5: "The tusk of a castrated boar. Auspicious.",
    6: "Following the originating power (lit. heaven), smooth."
    },
  },
  27: {
    name: "Nourishment",
    subtitle: "Providing Nourishment",
    description: "Nourishment is the wisdom of nourishing what truly matters. It's about how we sustain ourselves not just physically, but mentally and spiritually. Thunder beneath the mountain reflects the hidden power of nourishment—steadiness containing dynamic energy.",
    judgment: "Nourishment. Persistence brings good fortune. Observe nourishment—seek what nourishes your mouth (and spirit) yourself.",
    lines: {
    1: "Abandoning the wisdom you sought, and seeking nourishment for someone else, brings harm.",
    2: "Reverse how you nourish yourself, and go against the norm. Seeking the external nourishment brings misfortune.",
    3: "To go against nourishment in order to remain faithful brings misfortune. For ten years, do not act; there is no benefit in it at all.",
    4: "Looking down on nourishment brings good fortune. Like a tiger watching, eager to pursue. This is without fault.",
    5: "Going against the norm. Holding inner alignment brings good fortune. Do not cross the great river.",
    6: "Acting from true nourishment: though there is danger, there is good fortune. It is favorable to cross the great river."
    },
  },
  28: {
    name: "Critical Mass",
    subtitle: "Great Exceeding",
    description: "Excess represents a time of imbalance and strain. Strength and adaptability are necessary to navigate challenges. There is an overload that requires mindful correction to prevent collapse and restore harmony.",
    judgment: "Great transgression (or great exceeding). The main beam crosses the limit. It furthers one to have somewhere to go. Smooth (or progress)",
    lines: {
    1: "Placed upon white reed grass. No blame.",
    2: "A withered poplar grows new shoots. An old husband receives his wife. Nothing that would not bring benefit.",
    3: "The ridgepole is weak and bends (as if under pressure). This is misfortune.",
    4: "The ridgepole rises/is strong and prosperous. Good fortune. If there is something else (alternative), regret.",
    5: "The withered poplar produces blossoms. An old woman marries an official as a husband. No fault, no fame.",
    6: "Going too far in fording. The water covers the head. Misfortune. No blame."
    },
  },
  29: {
    name: "The Abysmal",
    subtitle: "Dangerously Deep",
    description: "Dangerously Deep represents resilience and wisdom in the face of challenges. It advises embracing difficulty with stability and presence, encouraging persistence and adaptability. Obstacles are part of the journey, not detours from it.",
    judgment: "Water repeated, symbol of the Pit. If you are sincere, you have success in your heart and whatever you do succeeds.",
    lines: {
    1: "Repeating danger you drop into an even deeper pit. Misfortune follows.",
    2: "Danger lies in the pit. Seek the small to find your way forward.",
    3: "Entering pit after pit. Danger as if the pillow beneath your head. Entering the hollow brings trouble. Do not act.",
    4: "Offer a jar of wine and two bowls in a simple clay pot through the window; no blame in the end",
    5: "The pit is not full, the surface is level, no misfortune.",
    6: "Bound with fine cords and thrown into thorn-bushes; three years without escape; misfortune."
    },
  },
  30: {
    name: "The Clinging",
    subtitle: "Clarity",
    description: "Radiance is about clarity, connection, and the transformative power of light. It speaks about finding support in something lasting and reliable. Fire repeated represents Radiance—light that attaches to righteousness and transforms the world.",
    judgment: "Radiance. Favourable for perseverance. Success. Nurturing a gentle cow brings good fortune.",
    lines: {
    1: "Confused footsteps. One honors him.",
    2: "Yellow light. Great good fortune.",
    3: "In the light of the setting sun, one beats a clay jar and sings. This is the sound of old age. Misfortune.",
    4: "Suddenly comes the burning. Death. Rejection.",
    5: "Tears flow in torrents. Sighing in grief. Good fortune.",
    6: "The king uses him to go forth and chastise. Then it is right to cut off the leaders, but do not capture their followers. No error"
    },
  },
  31: {
    name: "Influence",
    subtitle: "Attraction",
    description: "Influence speaks of the subtle power of connection. True attraction and mutual resonance lead to influence and harmony. Like a lake resting atop a mountain, be receptive and reflective to create authentic connection.",
    judgment: "Influence. Success. It is beneficial to be steadfast. Taking a wife brings good fortune.",
    lines: {
    1: "Influence at the toes.",
    2: "Influence at the calves. Misfortune. Staying still brings good fortune.",
    3: "Influence reaches the thighs. Acting from raw instinct or clinging too tightly to desire leads to trouble.",
    4: "Remaining true to one's way brings good fortune. Regret fades away; nothing to worry about. Eagerly longing, interacting back and forth. Your desires follow willfully.",
    5: "Influence at the flesh of the back. No regret.",
    6: "Influence in the cheeks, jaw, and tongue."
    },
  },
  32: {
    name: "Duration",
    subtitle: "Long Enduring",
    description: "Continuity is about effortless power that arises from alignment with unchanging principles. Thunder and wind move together—action and gentleness responding to each other. Understanding what is lasting reveals the nature of all things.",
    judgment: "Continuity. Smooth progress and freedom from fault. It is beneficial to be upright. Beneficial to have somewhere to go.",
    lines: {
    1: "Too intense in persistence. Continuing steadily is misfortune. There is no benefit at all.",
    2: "Regret disappears",
    3: "One who does not persist in virtue may bring shame. Even with correct intentions, there is regret.",
    4: "In the field, no game is caught.",
    5: "Follow your heart. Holding to the rules brings good fortune to the woman, but misfortune to the man.",
    6: "Someone does not stay constant in following the heart, and instead bears shame. Though he was right at first, regret still follows."
    },
  },
  33: {
    name: "Retreat",
    subtitle: "Withdrawal",
    description: "Retreat is about knowing when to step back to avoid unnecessary conflict or harm. Progress and success come not from confrontation. Stepping back allows recognizing the need to adapt to changing circumstances. True strength lies in knowing when to yield.",
    judgment: "Retreat. Success. Perseverance in small matters is favorable.",
    lines: {
    1: "Withdrawing before the end. Danger to initiate anything.",
    2: "To fix it, use the hide of a yellow ox. No one can undo it.",
    3: "Retreating with entanglements. There is distress and danger. It is fortunate to keep servants and concubines.",
    4: "A proper retreat. The noble one finds good fortune; the petty one does not.",
    5: "An admirable retreat. Trusting your direction brings good fortune.” An admirable retreat",
    6: "A full and well-prepared retreat. Nothing is unfavorable."
    },
  },
  34: {
    name: "Great Strength",
    subtitle: "Power of the Great",
    description: "Great Strength is about purposeful action balanced by humility and aligned with the natural order. This is a time of significant energy and momentum. Success lies in channeling this force thoughtfully towards what is meaningful and appropriate.",
    judgment: "Great Strength. Advantageous to remain aligned",
    lines: {
    1: "Eager to advance. There will be evil",
    2: "Reaming grounded and aligned brings good fortune",
    3: "The small person applies forceful action. The noble person avoids getting caught in action (or \"uses restrained\"). Holding ti correctness brings difficulties (or danger). The sheep butts the fence. Its horns get entangled",
    4: "Remaining aligned, good fortune comes. Doubt falls away. The fence opens—nothing is caught. Strength holds the load and lets the way unfold",
    5: "The ram loses its impulsive nature (symbolized by losing a toe or the urge to butt) — great good fortune",
    6: "The ram butts against the fence unable to retreat or proceed. No direction is beneficial. Accept the difficulty—then comes good fortune"
    },
  },
  35: {
    name: "Progress",
    subtitle: "Advance",
    description: "Progress is about forward movement supported by trust. Like the sun rising over the Earth, progress is steady and natural. It allows the process to unfold in its own time with each step bringing more clarity and growth.",
    judgment: "Progress. Many horses are given. Three times during the day, he meets with people.",
    lines: {
    1: "Progressing and returning (lit. \"advancing, yet blocked\"). Remaining grounded (abiding in stability) is auspicious. There is no trust. If you are relaxed and spacious, there is no error.",
    2: "Progressing, but with sorrow. Holding firm is fortunate. Great blessing is received, as if from the ancestral queen.",
    3: "All endorse—regret disappears.",
    4: "Advancing like a mole rat. Constancy leads to danger.",
    5: "Give up regret (or \"give up doubts\", also/lit. \"misgiving vanish\"). Don’t worry about loss or gain. Continuing brings good fortune. Nothing is unfavorable.",
    6: "Progressing with horns. Used to attack a city. Danger brings fortune. No blame—but persistence brings regret."
    },
  },
  36: {
    name: "Darkening of the Light",
    subtitle: "Clouded Perception",
    description: "Darkening of the Light is about a challenging time we must face with trust and resilience. Dark times test your strength and refine your spirit. Your inner light may need to remain shielded, but it never extinguishes.",
    judgment: "Darkening of the Light. Favourable for persevering through hardship.",
    lines: {
    1: "Darkening of the light during flight. Lowers wings. The noble person refrains from eating for three days. On the road, there is a place to go. The host speaks of this.",
    2: "Light is obscured, left thigh (ability to transform) is injured. Use of strong horses brings good fortune.",
    3: "Brightness is hidden. While conquering in the south, the great leader is captured. Yet it is not advisable to hastily set things right.",
    4: "Darkening of the light enters the left belly. Obtains the mind of darkness’s gate. Goes out and leaves the courtyard gate.",
    5: "Like Ji Zi in times of darkened light: it is beneficial to remain steadfast.",
    6: "What hides brightness first rises to heaven, then it descends to the earth."
    },
  },
  37: {
    name: "The Family",
    subtitle: "Household",
    description: "The Family represents harmony and structure within a family. It speaks of the balance of inner forces and alignment with cosmic principles. It emphasizes respect for roles, care and unity which ripple outward.",
    judgment: "The Family. Favorable for the woman to remain steadfast.",
    lines: {
    1: "A wooden bolt across the gate of a household. Regret vanishes.",
    2: "There should be no personal agenda to pursue, just to be in the center, providing food. Remaining aligned brings good fortune.",
    3: "When tempers flare up in the family, rigorous severity brings regret. Good fortune in the end. When woman and child dally and laugh, it leads to humiliation.",
    4: "She is the treasure of the house. Great good fortune.",
    5: "As a king he approaches his family. Fear not. Good fortune.",
    6: "Trusting therefore dignified. Finally good fortune"
    },
  },
  38: {
    name: "Opposition",
    subtitle: "Mutual Alienation",
    description: "Opposition is about navigating differences while seeking harmony. Paths diverge yet understanding and small actions can create balance. The key is to respect differences without losing connection.",
    judgment: "Opposition. Small actions are favourable.",
    lines: {
    1: "Regret disappears. Lose the horse — do not chase it, it will return. Even harshness does not bring error.",
    2: "Meeting the ruling principle.",
    3: "One sees the cart dragged back, the ox checked. The person is branded on the forehead and has the nose cut off. No beginning, but an outcome.",
    4: "Though isolated in opposition, you meet a wise individual. Trust is established. There may be difficulty, but there is no error.",
    5: "Regret disappears. His ancestor bites the skin. What misfortune is there in going?",
    6: "Opposition and isolation. Sees a pig covered with mud, one is heavy with fears, and projections. First, pulls the bow. Then, the bow is put aside. This is not a bandit, but a union. Go through the rain, there will be good fortune."
    },
  },
  39: {
    name: "Obstruction",
    subtitle: "Impasse",
    description: "Obstruction represents a time of difficulty where progress feels blocked. Obstacles carry lessons. The wise person learns when to pause, reflect, and strengthen their inner resolve.",
    judgment: "Obstruction. Favourable in the southwest. Unfavourable in the northeast. Beneficial to see the great person. Persistence brings good fortune.",
    lines: {
    1: "Going forward brings crippling obstruction; Returning brings praise.",
    2: "The king’s minister meets obstruction upon obstruction. It is not for his own sake.",
    3: "Moving forward in obstruction, coming back is opposed.",
    4: "Going brings obstruction, staying is unity.",
    5: "In great obstruction, friends arrive.",
    6: "Through going through difficulty, fullness can return. This brings good fortune. Great for the noble person to show up."
    },
  },
  40: {
    name: "Deliverance",
    subtitle: "Liberation",
    description: "Deliverance represents a time of relief and release from difficulties. It advises letting go of tension, embracing renewal, and acting with purpose. Deliverance encourages shedding burdens to rediscover clarity.",
    judgment: "Deliverance. The southwest furthers. If there is no longer anywhere where one has to go, return brings good fortune. If there is still somewhere where one has to go, hastening brings good fortune",
    lines: {
    1: "There is no fault.",
    2: "In the field, one captures three foxes; gains yellow arrows. Keeping the right direction brings good fortune.",
    3: "Carrying a burden while riding in comfort. This invites robbers. Even with correct intent, the outcome is strained.",
    4: "Release your thumb (or \"big toe\"). Companions arrive. Then there is trust.",
    5: "The bondage of the Superior Man is released. Auspicious. He has trust toward the smallness in people.",
    6: "The noble one shoots a falcon on top of the high wall. He captures it—there is nothing unfavorable."
    },
  },
  41: {
    name: "Decrease",
    subtitle: "Reduction",
    description: "Decrease is about letting go of the unnecessary to create space for growth of what is important. Reduce excess and leave only what is essential. When you are genuine, even small gestures have great significance.",
    judgment: "Decrease. Trusting brings supreme good fortune. There is no error. It is suitable to remain stable. Beneficial to go somewhere. How this should be done? Two bowls may be used for the offering",
    lines: {
    1: "It has been done. Don’t delay. There is no fault. Let go of it.",
    2: "Remaining correct is beneficial. To go somewhere brings misfortune. Without giving away, you are able to bring increase.",
    3: "Three people travel together, and one person must leave. One of them goes alone, and gains an ally.",
    4: "Reducing the illness/defect makes joy come swiftly. There is no error.",
    5: "Someone benefits it; the tortoise shells of ten friends do not disobey; great good fortune.",
    6: "Not decreasing is to increase it. This is without any error . Remaining grounded abiding in fullness is auspicious. Staying aligned while attracting fully devoted attendants (without home or family)."
    },
  },
  42: {
    name: "Increase",
    subtitle: "Augmentation",
    description: "Increase centers on growth, support and beneficial actions. It's about uplifting others and fostering shared prosperity. This is about creating value for all. The energy of growth is dynamic and expansive.",
    judgment: "Increase. It furthers one to undertake something. It furthers one to cross the great water",
    lines: {
    1: "It is beneficial to undertake a great task. Supreme good fortune, there is no error.",
    2: "Someone bestows upon you a tortoise worth ten pairs of cowries, and you cannot refuse it. Lasting perseverance brings good fortune. The King uses it to make offerings to the Highest Divinity.",
    3: "Being increased by unfortunate events is without error. Having inner sincerity / truthfulness and walking the middle path, announce it to the ruler, using your jade scepter",
    4: "Centered action. Report to the ruler, and he will follow. It is favorable to establish a foundation for moving the state",
    5: "Having true kindness in the heart; do not aske about it; supreme good fortune My truly kind heart is rewarded with increase",
    6: "No one benefits from it, or someone even strikes him. He does not keep his heart steadfast. Misfortune. Selfishness and inconsistency bring loss and conflict."
    },
  },
  43: {
    name: "Breakthrough",
    subtitle: "Resolution",
    description: "Breakthrough signals a turning point to act decisively and overcome obstacles. Balance clarity and courage to avoid rushing or becoming aggressive. Sensitivity to the situation is key.",
    judgment: "Breakthrough. Make a public announcement as a place of authority. Earnestly breaking out - there is something harsh. Apply it to your own self (lit. announce one's own city). It is not favorable to openly fight. It is favorable to undertake something.",
    lines: {
    1: "Strong at the front toes (forceful beginning). Going forward without capacity leads to blame.",
    2: "Be vigilant and raise the alarm. At night there is danger of conflict. Do not be anxious.",
    3: "Strong on the cheekbones—misfortune follows. The noble one is firm and decisive. He walks alone, if goes goes through rain, there is frustration but no fault.",
    4: "The buttocks have no skin. The movement is halting and hesitant. Let the sheep be pulled and regret will disappear. These words are heard but not believed.",
    5: "Creeping plant on earth required true resolution. Alignment with your direction is without blame.",
    6: "No warning is given. In the end, it leads to disaster."
    },
  },
  44: {
    name: "Coming to Meet",
    subtitle: "Encountering",
    description: "Encounter represents an unexpected and potentially overpowering meeting. It is a warning to stay alert and maintain your integrity. Avoid forces or situations that could dominate or disrupt your balance.",
    judgment: "Encounter. The woman is bold. It is not advisable to marry her",
    lines: {
    1: "Tied to a metal brake. Being upright brings good fortune. If one goes somewhere, will see misfortune. A weak pig trusts but hesitates.",
    2: "Holding a bag with fish inside. This is not a mistake. It's not favourable to share it .",
    3: "The hips have no skin. One moves hesitantly and awkwardly. There is trouble. This is not a great disaster.",
    4: "The bag hides no fish. Rising up [in this situation] brings misfortune.",
    5: "Wrapping a melon while full of unnecessary worries. Something falls from heaven",
    6: "Encountering with his horns. Regret, but no blame"
    },
  },
  45: {
    name: "Gathering Together",
    subtitle: "Assembling",
    description: "Gathering represents the power of unifying different aspects of life. Bring them together under one unifying principle. When guided by this principle, any action becomes effortless and powerful.",
    judgment: "Gathering. Success. The king aligns with Heaven before he acts. It is beneficial to see a great person. Success. It’s beneficial to align with your purpose. Using great offerings is auspicious. It is favorable to have a direction to go.",
    lines: {
    1: "There is confidence, but it does not last. Chaos returns, then gathering again. If one cries out and grasps it, this turns into laughter. To go forward is without fault.",
    2: "Leading to auspiciousness (or extremely auspicious) and without error. A small offering, given in good faith, brings benefit.",
    3: "The heart wants to gather, but the time resists. Proceed gently. There is no harm, though you may sigh",
    4: "Great good outcome, there is no error",
    5: "Right position brings gathering. If there is no trust, great and lasting integrity is the right path",
    6: "Sighing and groaning, tears and snivel—no fault."
    },
  },
  46: {
    name: "Pushing Upward",
    subtitle: "Growing",
    description: "Pushing Upward represents steady progress and the power of perseverance. It encourages clear vision, trust in your journey, and quiet determination. Progress is like wood growing steadily within the Earth—unseen but unstoppable.",
    judgment: "Rising. Great progress. Favorable to see the noble one. Do not worry. Southward expansion brings good fortune.",
    lines: {
    1: "Truly welcomed ascending. Great good fortune follows.",
    2: "if you are trustworthy, even small offering brings good fortune.",
    3: "Ascending into an empty city",
    4: "The king performs a sacrifice at Mount Qi. Auspicious and without fault",
    5: "Remaining aligned: good fortune, and ascending the steps.",
    6: "Rising into darkness. It is favorable to persist with unwavering integrity"
    },
  },
  47: {
    name: "Oppression",
    subtitle: "Exhaustion",
    description: "Oppression reflects a time when constraints and limitations are strong. This is a time of difficulty but it holds potential for growth and clarity if approached with patience and a firm spirit.",
    judgment: "Lake over water symbolizing Oppression. Success can come. Perseverance is rewarded. The great person finds good fortune. There is no blame. His words are not trusted.",
    lines: {
    1: "Oppression from the start — you sit under a bare tree, isolated. Dangerous to move; better to stay still and endure quietly.",
    2: "Engaged is enjoying wine and food, while the red sash (symbol of authority) is just about due to arrive. It is beneficial to make offerings. To depart from this brings misfortune. There will be no error.",
    3: "Trapped by a rock and grasping thorns. He enters his home but does not notice his wife there. This is a trouble.",
    4: "Coming slowly, very slowly. Oppressed by a valuable metal cart. These is a regret, but there is an end.",
    5: "Nose and feet are cut off. Oppressed in red robes. Then, gradually, there is relief and joy. It is beneficial to make offerings.",
    6: "Trapped by vines and creepers, in a shaky, precarious place. It says: \"Movement brings regret.\" Having regret, to advance is fortunate"
    },
  },
  48: {
    name: "The Well",
    subtitle: "Replenishing",
    description: "The Well is an inexhaustible resource of fulfillment. It is a source of life support or sustenance for the heart. Amid life's changes, its sustenance is there for those who dare to reach for it.",
    judgment: "Its surrounding may change, the well does not ever change. It never depletes or overflows. People walk back and forth to the well. The rope is too short to draw water from the well, almost reaching it. Then breaking the pitcher invites adversity.",
    lines: {
    1: "Muddy water in the well. Not fit to drink. No birds come to the old well.",
    2: "The well is in a valley. Shooting at small fish. The jar is damaged and leaking.",
    3: "The well has been cleared. It is not used, the heart is in sorrows. It can be used, the highest wisdom (lit. also \"the king is wise\") can benefit many with its blessings.",
    4: "The well is lined with bricks. No blame.",
    5: "The well is clear and pure. Cold spring water is drunk.",
    6: "The well is covered, but not concealed. With sincerity, great good fortune."
    },
  },
  49: {
    name: "Revolution",
    subtitle: "Transformation",
    description: "Revolution teaches the art of transformation. Change must come at the right time with sincerity and purpose. True change brings harmony when rooted in honesty and alignment with natural cycles.",
    judgment: "Revolution. On the day it is completed, trust will follow. Great success, benefit, and steadfastness. Regret disappears.",
    lines: {
    1: "Wrapped in the hide of a yellow cow. Remain firm and patient. Don't rush transformation. Stay grounded.",
    2: "When one's own day comes, one may create revolution. Starting brings good fortune. No blame. When the time is right, act. Proper timing brings success.",
    3: "Taking action brings harm. Even aligning with the heart is dangerous. Change has been discussed three times. Hold to trust.",
    4: "Remorse disappears. Men believe him. Changing the form of government brings good fortune. Credibility established. Transformation accepted and blessed.",
    5: "The great man changes like a tiger. Even before he questions the oracle he is believed. Like a tiger's stripes—transformation is clear and unmistakable. Trust is immediate.",
    6: "The superior man changes like a panther. The inferior man molts in the face. Starting brings misfortune. To remain persevering brings good fortune. Subtle transformation for the wise. For the small-minded, only surface change. Stay steady."
    },
  },
  50: {
    name: "The Caldron",
    subtitle: "Establishing the New",
    description: "The Cauldron symbolizes transformation and nourishment. It represents a vessel of change where raw ingredients are refined into something nourishing and complete. This is a time for elevating what is worthy.",
    judgment: "Cauldron. Supreme good fortune. Success.",
    lines: {
    1: "The cauldron is overturned. Throw out old residue.",
    2: "The cauldron is full. Resistance cannot stop me; what is not mine does not approach. This is good fortune.",
    3: "The cauldron’s handles are altered / removed. Its movement is blocked. The rich food is not eaten. Rain begins to fall. Regret diminished. In the end, good fortune.",
    4: "The legs are broken; the food spills.",
    5: "The cauldron has yellow handles and golden rings. Auspicious.",
    6: "The cauldron has a jade handle. Great good fortune. Nothing is not beneficial."
    },
  },
  51: {
    name: "The Arousing",
    subtitle: "Shock",
    description: "Shock represents a moment of profound movement or awakening. It embodies the transformative power of shock and the potential for growth it brings. Thunder startles but also clears, leaving sharper awareness.",
    judgment: "Thunder. Success. Shock comes—alarming and trembling. Laughter and talk fade. Shock spreads a hundred miles. Yet the ritual vessels remain unbroken.",
    lines: {
    1: "Thunder comes bringing fear. Afterward laughter and chatter. Ease returns. Favorable.",
    2: "Harsh shock arrives. Suddenly wealth can be lost. Climb high grounds and do not chase what is lost. It will all be returned in seven days",
    3: "Thunder shakes and revives. One moves, and there is no fault.",
    4: "Shock continues bringing entanglements.",
    5: "Sever shock coming and going. But there is not much loss. Duty must be carried out",
    6: "Trembling and anxious. Eyes darting in fear. To advance brings misfortune."
    },
  },
  52: {
    name: "Keeping Still",
    subtitle: "Mountain",
    description: "Keeping Still invites embracing stillness and inner calm. It teaches that knowing when to pause is as essential as knowing when to act. True strength comes not from constant motion but from purposeful restraint.",
    judgment: "Keeping still. Still your back. Do not grasp your body. Walk in the courtyard without seeing others. No blame.",
    lines: {
    1: "Stopping his feet — stop before starting the wrong path.",
    2: "Stopping his calves — no rescue; don't follow others' restless energy.",
    3: "Stopping his hips — dangerous straining; forced action creates regret.",
    4: "Keeping the body still — this is faultless.",
    5: "Still the cheekbones; let words be measured and timely — regret fades.",
    6: "Trust in stillness — good fortune"
    },
  },
  53: {
    name: "Gradual Progress",
    subtitle: "Development",
    description: "Gradual Progress represents steady and deliberate advancement. It emphasizes patience, integrity and alignment with natural rhythms. Like wind shaping the mountain, lasting change comes through gentle persistence.",
    judgment: "Gradual Progress. The maiden is given in marriage. Perseverance furthers.",
    lines: {
    1: "The wild goose gradually approaches the riverbank. The young one is in danger. There is talk. There is no fault.",
    2: "The wild goose approaches a rock. There is joyful eating and drinking. Good fortune.",
    3: "The wild goose gradually approaches dry land. The man marches (joins a military campaign) but does not return. The woman gets pregnant but does not nurture the child (or give birth). This is misfortune. It's beneficial to defend from the invaders.",
    4: "The wild goose gradually draws near the tree. It may find a flat branch. No blame.",
    5: "The wild goose gradually draws near the summit. For three years the wife has no child. In the end nothing can thwart her. Good fortune.",
    6: "The wild geese gradually approach the cloud heights. Their feathers can be used in the sacred dance. Good fortune."
    },
  },
  54: {
    name: "The Marrying Maiden",
    subtitle: "Subordinate Position",
    description: "The Marrying Maiden is about adapting to an improper or constrained position. It addresses occupying a secondary role or entering relationships with imbalance. Handle challenges of subordination with awareness and grace.",
    judgment: "The Marrying Maiden. Undertakings bring misfortune. Nothing is favorable.",
    lines: {
    1: "Young Maiden marries as a concubine. Though she is crippled, she can walk. To take action brings good fortune.",
    2: "Though partially blind, one is able to see. Good fortune comes from staying true to the path of the withdrawn person.",
    3: "The marrying maiden acts like a slave. She marries but leaves.",
    4: "The marrying maiden returns home after missing the appointed time for marriage.",
    5: "The Emperor gives away his daughter. The wedding robe is not as fine as the everyday clothes. The moon is nearly full. Good fortune",
    6: "The woman holds a basket, but there is nothing in it. The man sacrifices a sheep, but there is no blood. No advantage."
    },
  },
  55: {
    name: "Abundance",
    subtitle: "Fullness",
    description: "Abundance symbolizes dynamic brilliance like thunder and lightning. This is a peak moment but also carries warning—if you don't nurture this brilliance, it will fade like the sun after noon. Act decisively.",
    judgment: "Abundance. Success. The king is present. Have no anxiety. It is suitable to reach the zenith.",
    lines: {
    1: "Meeting his proper match. Though equal, there is no harm. Going forward brings respect.",
    2: "The curtain is so abundant that at midday one can see the North Star. Going forward brings suspicion and illness. If one is sincere, it will be like the bright sun at noon.",
    3: "The underbrush is abundant. At midday one sees small stars. Break your right arm. No harm.",
    4: "Abundant cover, the sun at midday sees the Dipper, encountering its barbarian ruler, auspicious.",
    5: "Lines of brilliance come. Congratulations and honor are there. Good fortune.",
    6: "His house is in abundance. He screens his family. Peering through the gate, he sees no one for three years. Misfortune."
    },
  },
  56: {
    name: "The Wanderer",
    subtitle: "Transition",
    description: "The Wanderer is about navigating transitional times and unfamiliar situations. It advises adaptability, clarity and perseverance. Balance inner stability with outer flexibility during temporary circumstances.",
    judgment: "The Traveller. Success through subtle actions. It is advantageous for the wanderer to be steadfast and correct.",
    lines: {
    1: "The traveler is petty and small-minded. Thus, this is what brings misfortune upon him.",
    2: "The traveler comes to an inn (a stopping place). He cherishes his resources in his bosom. He obtains loyal young servants.",
    3: "The traveler burns his inn, and loses his loyal young servants. Persistence in this leads to danger.",
    4: "The traveler is at a makeshift dwelling. He obtains his resources and an axe. But in my heart, I am not at ease.",
    5: "He shoots a pheasant. He loses one arrow. In the end, this leads to praise and an appointment.",
    6: "The bird burns its own nest. The traveler first laughs and then wails. He loses his ox in the borderlands/carelessly. Misfortune."
    },
  },
  57: {
    name: "The Gentle",
    subtitle: "Penetration",
    description: "The Gentle embodies subtle influence and steady persistence. It is represented by wind which moves softly but reaches everywhere. This hexagram advises approaching challenges with patience and quiet strength.",
    judgment: "Subtle penetration. The subtle succeeds. Favorable to have somewhere to go. Favorable to see the great person.",
    lines: {
    1: "Advancing and retreating. It benefits to abide in stability like a warrior",
    2: "Penetration is under the bed, use historians and visionaries when it appears tangled. This is auspicious and without error",
    3: "Urgent and frequent penetration brings regret",
    4: "Regret is gone. In the field, one catches three kinds of game",
    5: "Aligning with good fortune, remorse is gone. Nothing that does not further. No beginning, but an end. Before the Geng day, three days; after the Geng day, three days. Good fortune",
    6: "The gently penetrating what is subtle under the bed. He loses his axe. Remaining brings misfortune"
    },
  },
  58: {
    name: "The Joyous",
    subtitle: "Lake",
    description: "Joy symbolizes tranquility and inner delight. This mental state is harmonious and fosters external progress. Joy represents energy that inspires inner resolve and vision—spontaneous, effortless, naturally balanced.",
    judgment: "Joyful. Smooth progress. Favorable to remain true.",
    lines: {
    1: "There is good joy, good fortune",
    2: "Trusting joy brings good fortune; regret disappears.",
    3: "Joy that comes from outside. Ominous.",
    4: "Joy that is hesitant. Not yet settled. There will be cause for joy.",
    5: "Trust in what is eroded. Dangerous, but no mistake.",
    6: "Leading others into joy."
    },
  },
  59: {
    name: "Dispersion",
    subtitle: "Dissolution",
    description: "Dispersion represents breaking apart stagnation or obstacles. It advises openness, unity and flow. Dispersion encourages dissolving barriers to achieve clarity and harmony—whether within or around us.",
    judgment: "Dispersion. Success. The king approaches his temple. It is beneficial to cross the great river. It is favourable to remain steadfast.",
    lines: {
    1: "Rescue with the aid of a strong horse—good fortune.",
    2: "In dispersion, make a sudden change of direction. There will be no place for regret.",
    3: "The third line shows one discarding all self-concern—there is no occasion for repentance.",
    4: "Scattering own flock brings prime good fortune. Scattering has it's mound (newfound center) this is beyond ordinary thought",
    5: "The grand proclamation dissolves the sweat of effort; rigid rule dissolves as well. This is without error.",
    6: "He disperses his wounds, departs far, and exits. Without fault."
    },
  },
  60: {
    name: "Limitation",
    subtitle: "Restrictive Regulations",
    description: "Limitation emphasizes the power of boundaries and moderation. It shows that proper limits allow for sustainable growth and successful navigation. Balance is essential—excess brings suffering.",
    judgment: "Limitation. Success. Bitter limitation is not to be persisted in.",
    lines: {
    1: "Not going beyond the gate and courtyard is without error.",
    2: "Not going beyond the gate and courtyard — misfortune.",
    3: "If one fails to practice boundaries, there will be regret. Yet there is no error.",
    4: "Keeping boundaries with ease and stability. Success.",
    5: "Pleasant (or sweet) limitations bring blessing. Moving forward is auspicious.",
    6: "Bitter limitation. Persisting in it brings misfortune. Letting go removes regret."
    },
  },
  61: {
    name: "Inner Truth",
    subtitle: "Sincerity",
    description: "Inner Truth represents the power of sincerity and clarity. It calls for trust in your authentic self and the natural flow of life. When aligned with inner truth, challenges are more easily overcome.",
    judgment: "Inner truth (or heart confidence). Piglets and fishes and auspicious. Favorable to cross the great river. Favourable to remain true to yourself.",
    lines: {
    1: "Alertness is auspicious. The other (distraction or influence) brings no peace.",
    2: "The crane cries out from the shade, and its young one echoes back in harmony. 'I have fine wine vessels. I will share them with you'",
    3: "Encountering an opponent. Sometimes drum, sometimes stop. Sometimes weep, sometimes sing",
    4: "The moon is nearly full. The horses are lost. No fault",
    5: "There is confidence which is like an invisible bond tying all together. This is without error",
    6: "Flying call rises to heaven. Being correct, brings misfortune"
    },
  },
  62: {
    name: "Small Exceeding",
    subtitle: "Preponderance of the Small",
    description: "Small Exceeding advises that success lies in the details. Focus on small things and life's miracles. Let go of big expectations. Gentle precise acts address challenges better than ambitious overwhelming goals.",
    judgment: "Little overreach. This is success. It is favourable to be steadfast. Small matters bring benefit; big matters do not A bird flies and leaves its song. It is better to go down than to rise up. Great good fortune.",
    lines: {
    1: "The bird flies and meets misfortune",
    2: "Passing her ancestor, she meets her grandmother. He does not reach his lord; he meets his minister, no error",
    3: "Not overdoing it, he who follows may be in danger.",
    4: "There is no fault - through not going too far; one meets. Going brings danger, must be cautious. Do not use constant uprightness",
    5: "Thick clouds, but no rain, coming from the region to my west. The noble hunts and takes that in its hole.",
    6: "Not meeting it (overshooting), going beyond. The flying bird parts from it. Misfortune. This is called disaster and harm"
    },
  },
  63: {
    name: "After Completion",
    subtitle: "Already Fulfilled",
    description: "After Completion reflects a moment when balance and harmony have been achieved. This state is delicate and may gradually be disturbed. Subtle attention is needed to maintain equilibrium over the long term.",
    judgment: "After Completion, success. The small and subtle succeeds. At the beginning or now this is auspicious. It may end in disorder.",
    lines: {
    1: "Trailing the cycles, the tail gets moist. There is no error",
    2: "The woman loses her carriage curtain. Do not go after it. In seven days, you will get it",
    3: "The High Ancestor attacks the Land of Ghosts. Three years — he conquers it. The small person: do not employ",
    4: "The finest clothes are tattered. Be cautious all day long.",
    5: "The eastern neighbor kills an ox, not like the western neighbor's spring offering. He receives the blessing.",
    6: "He gets his head wet. Danger."
    },
  },
  64: {
    name: "Before Completion",
    subtitle: "Unfinished Business",
    description: "Before Completion represents a time of transition—the final stretch before a goal is reached. There is warning that things may not go as planned just before completion. This is not a moment to be overconfident.",
    judgment: "Before Completion, success. The small fox nears completion. Wetting its tail nothing is beneficial.",
    lines: {
    1: "He wets his tail—there is shame (or trouble).",
    2: "Dragging the wheels. Remaining true to your direction brings good fortune.",
    3: "Before completion. Advancing brings misfortune. Yet it is favorable to cross the great river.",
    4: "Remaining aligned with your path bears fruit. Worry and regrets are now gone. The thunder of Heaven has struck the land of demons. The three-year ordeal is complete and the great state bestows its rewards.",
    5: "True to one’s path in life — and therefore blessed. Nothing to regret. The noble person shines trusting his way. Good fortune.",
    6: "There is drinking wine with truthfulness; no blame. If he wets his head, trust is lost and this is a mistake."
    },
  },
};
