import type { Context } from "@netlify/functions";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic();

const SYSTEM_PROMPT =
  "You are a wise, gentle Yi Jing (I Ching) presence guide. You help seekers explore " +
  "present-moment awareness through the wisdom of the hexagram they received. Keep responses " +
  "short (1-3 sentences), warm, conversational, and grounded in direct experience of the body, " +
  "feelings, and mind. Never give medical, legal, or financial advice.";

export default async (req: Request, context: Context) => {
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  let prompt: string | undefined;
  try {
    const body = (await req.json()) as { prompt?: string };
    prompt = body.prompt;
  } catch {
    prompt = undefined;
  }

  if (!prompt || typeof prompt !== "string" || prompt.length > 8000) {
    return Response.json({ error: "Missing or invalid prompt" }, { status: 400 });
  }

  try {
    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 300,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: prompt }],
    });
    const text =
      message.content
        .filter((block) => block.type === "text")
        .map((block) => (block as { text: string }).text)
        .join("\n")
        .trim() || "What arises in this moment?";
    return Response.json({ response: text });
  } catch {
    return Response.json(
      { response: "What arises in this moment?" },
      { status: 200 }
    );
  }
};

export const config = {
  path: "/api/presence",
};